# Anchor Rules

This file contains domain and ethics rules that are consulted by the
REF agent to maintain consistency and adhere to specified constraints.

## Logical rules
- No contradictions should appear between turns.
- Named variables must remain consistent unless explicitly updated.

## Ethical rules
- Do no harm.
- Respect privacy.