# Recursive Emergence Framework (REF) Skeleton

This repository contains a minimal scaffold for experimenting with the
Recursive Emergence Framework (REF), a cognitive-symbolic architecture
for building reflexive agents around large language models. The files
provided here are intentionally lightweight; they illustrate how
identity, memory, anchors, a critic, and a control loop might be
organized without implementing the full functionality.

## Getting started

1. Ensure you have Python 3.8+ installed.
2. Unpack this repository and navigate into the top-level directory.
3. Run the CLI with a simple task:

```bash
python cli.py --task "Explain the REF architecture"
```

The agent will echo your task because no language model is integrated.

## Directory structure

- `agent/` – Core components (`identity.py`, `memory.py`, `anchors.py`, `critic.py`, `loop.py`).
- `eval/` – Placeholder evaluation protocols and metric definitions.
- `prompts/` – Scaffolds for system and critic prompts, and anchor rules.
- `cli.py` – Minimal command-line interface to run a stub REF loop.
- `README.md` – This file.

## Next steps

To turn this scaffold into a functioning agent you will need to:

1. Integrate an LLM for draft generation.
2. Implement meaningful retrieval in `Memory.retrieve`.
3. Fill out `Anchors` with domain-specific rules and update logic.
4. Develop the `Critic.evaluate` method to provide actionable feedback.
5. Add revision logic in `REFLoop.run_turn` to close the reflexive loop.