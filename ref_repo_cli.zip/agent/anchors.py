"""
anchors.py

This module defines a simple `Anchors` class used by the Recursive Emergence
Framework (REF) agent. Anchors hold symbolic constraints and domain rules
that the agent must respect, such as logical consistency rules or ethical
guidelines. They can also capture session-specific facts and domain-specific
jargon to maintain coherence across turns.

In a full implementation, the anchors would be actively consulted and
updated during the feedback and revision phases of the REF loop.
"""

from dataclasses import dataclass, field
from typing import List, Dict


@dataclass
class Anchors:
    """Container for symbolic constraints and domain knowledge."""

    logic: List[str] = field(default_factory=list)
    ethics: List[str] = field(default_factory=list)
    session_facts: List[str] = field(default_factory=list)
    jargon: Dict[str, str] = field(default_factory=dict)

    def add_fact(self, fact: str) -> None:
        """Add a session-specific fact to the anchors."""
        self.session_facts.append(fact)

    def add_rule(self, category: str, rule: str) -> None:
        """Add a rule to one of the rule lists (logic or ethics).

        Args:
            category: Either "logic" or "ethics".
            rule: The rule to add.
        """
        if category == "logic":
            self.logic.append(rule)
        elif category == "ethics":
            self.ethics.append(rule)