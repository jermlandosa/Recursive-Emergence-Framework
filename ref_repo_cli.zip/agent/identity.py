"""
identity.py

This module defines a simple `Identity` class used by the Recursive Emergence
Framework (REF) agent. An identity encapsulates persistent traits, roles, and
styling preferences that shape how the agent presents itself over the course
of an interaction.

For the purposes of this stub implementation, the class simply stores
the provided attributes without any additional logic.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any


@dataclass
class Identity:
    """A lightweight container for agent identity information."""

    traits: List[str] = field(default_factory=list)
    roles: List[str] = field(default_factory=list)
    style: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        return (
            f"Identity(traits={self.traits}, roles={self.roles}, "
            f"style={self.style})"
        )