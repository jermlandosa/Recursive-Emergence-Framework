"""
cli.py

This script provides a minimal command-line interface for interacting with
the Recursive Emergence Framework (REF) agent. It exposes a single
argument, `--task`, which specifies a user query or objective. The script
constructs the REF components (identity, memory, anchors, critic) and
invokes the `run_turn` method of the `REFLoop` to produce a response.

To run this CLI after unpacking the repository, execute:

    python cli.py --task "Explain the REF architecture"

Because the underlying implementation is a stub, the response will
simply echo the provided task prefaced with "Draft response:". The
scaffolding is intended to illustrate how a real agent might be wired up.
"""

import argparse

from agent.identity import Identity
from agent.memory import Memory
from agent.anchors import Anchors
from agent.critic import Critic
from agent.loop import REFLoop


def main() -> None:
    """Entry point for the CLI."""
    parser = argparse.ArgumentParser(description="Run a stub REF agent on a task")
    parser.add_argument(
        "--task",
        required=True,
        help="A description of the task or query for the agent to process."
    )
    args = parser.parse_args()

    # Instantiate REF components with default values
    identity = Identity(
        traits=["patient", "truth-seeking"],
        roles=["assistant"],
        style={"tone": "concise"}
    )
    memory = Memory()
    anchors = Anchors(
        logic=["no-contradiction", "var-consistency"],
        ethics=["no-harm"],
        session_facts=[],
        jargon={"REF": "Recursive Emergence Framework"}
    )
    critic = Critic()

    # Create the main loop and run a single turn
    loop = REFLoop(identity=identity, memory=memory, anchors=anchors, critic=critic)
    response = loop.run_turn(args.task)
    print(response)


if __name__ == "__main__":
    main()