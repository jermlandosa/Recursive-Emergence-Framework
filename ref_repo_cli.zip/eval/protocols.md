# Evaluation Protocols

This document outlines example tasks, prompts, and scoring rubrics for
evaluating a REF agent. The content is deliberately minimal to serve as
a placeholder. Extend these protocols with specific tasks that reflect
your domain and goals.

- **Task specification**: Describe a scenario and desired outcome.
- **Prompt**: Provide a representative prompt to initiate the task.
- **Scoring rubric**: Identify metrics (e.g., correctness, coherence) and
  how they will be measured or rated.